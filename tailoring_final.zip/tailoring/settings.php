<?php


require_once TAILORING_PLUGIN_DIR . '/includes/shortcodes.php';